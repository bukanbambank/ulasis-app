---
description: Show the current active voice and TTS provider
---

Display the currently selected TTS voice and active provider (ElevenLabs or Piper).

!bash .claude/hooks/voice-manager.sh whoami
