---
description: Get the currently selected ElevenLabs TTS voice
---

Display the currently selected ElevenLabs TTS voice.

This shows which voice is currently set as the default for TTS audio generation.

!bash .claude/hooks/voice-manager.sh get
