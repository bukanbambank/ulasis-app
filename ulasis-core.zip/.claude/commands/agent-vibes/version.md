---
description: Show the installed AgentVibes version
---

Display the currently installed version of AgentVibes.

Usage:
- `/agent-vibes:version` - Show version information

!bash npx agent-vibes --version
